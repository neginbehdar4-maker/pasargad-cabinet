module github.com/github/github-mcp-server/v2

go 1.27.3

require (
	github.com/go-chi/chi/v5 v5.4.0
	github.com/go-viper/mapstructure/v2 v2.5.0
	github.com/google/go-github/v92 v92.0.0
	github.com/google/jsonschema-go v0.4.3
	github.com/josephburnett/jd/v2 v2.5.0
	github.com/lithammer/fuzzysearch v1.1.8
	github.com/microcosm-cc/bluemonday v1.0.27
	github.com/modelcontextprotocol/go-sdk v1.8.0
	github.com/muesli/cache2go v0.0.0-20221011235721-518229cd8021
	github.com/segmentio/encoding v0.5.4
	github.com/shurcooL/githubv4 v0.0.0-20260209031235-2402fdf4a9ed
	github.com/shurcooL/graphql v0.0.0-20240915155400-7ee5256398cf
	github.com/spf13/cobra v1.10.2
	github.com/spf13/pflag v1.0.10
	github.com/spf13/viper v1.21.0
	github.com/stretchr/testify v1.12.1
	github.com/yosida95/uritemplate/v3 v3.0.2
	golang.org/x/net v0.61.0
	golang.org/x/oauth2 v0.37.0
)

require (
	github.com/aymerick/douceur v0.2.0 // indirect
	github.com/fsnotify/fsnotify v1.9.0 // indirect
	github.com/google/go-querystring v1.2.0 // indirect
	github.com/gorilla/css v1.0.1 // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/pelletier/go-toml/v2 v2.2.4 // indirect
	github.com/sagikazarmark/locafero v0.11.0 // indirect
	github.com/segmentio/asm v1.1.3 // indirect
	github.com/sourcegraph/conc v0.3.1-0.20240121214520-5f936abd7ae8 // indirect
	github.com/spf13/afero v1.15.0 // indirect
	github.com/spf13/cast v1.10.0 // indirect
	github.com/stretchr/objx v0.5.3 // indirect
	github.com/subosito/gotenv v1.6.0 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
	golang.org/x/sync v0.24.0 // indirect
	golang.org/x/sys v0.49.0 // indirect
	golang.org/x/text v0.43.0 // indirect
	golang.org/x/time v0.15.0 // indirect
)
